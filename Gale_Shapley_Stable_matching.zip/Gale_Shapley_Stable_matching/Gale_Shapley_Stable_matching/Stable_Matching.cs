﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gale_Shapley_Stable_matching
{
    internal class Stable_Matching
    {
        int size = 5;

        public bool EmpPreferP1OverP(int [][]EmpPrefer,int Emp,int P,int P1)
        {
            for (int i = 0; i < size; i++)
            {
                if(EmpPrefer[Emp][i]==P1)
                {
                    return true;
                }
                if(EmpPrefer[Emp][i] == P)
                {
                    return false;
                }
            }

            return false;
        }

        public void StableMatching(int [][]EmpPrefer)
        {
            int[] empPosition = new int[size];
            bool[] freePosition = new bool[size];

            for (int i = 0; i < size; i++)
            {
                empPosition[i] = -1;
            }
            int freeCount = size;

            while(freeCount>0)
            {
                int P;
                for (P = 0; P < size; P++)
                    if (freePosition[P] == false)
                        break;

                for (int i = 0; i < size && freePosition[P]==false; i++)
                {
                    int E = EmpPrefer[P][i];

                    if(empPosition[E-size]==-1)
                    {
                        empPosition[E - size] = P;
                        freePosition[P] = true;
                        freeCount--;
                    }

                    else
                    {
                        int P1 = empPosition[E - size];
                        if(EmpPreferP1OverP(EmpPrefer,E,P,P1)==false)
                        {
                            empPosition[E - size] = P1;
                            freePosition[P] = true;
                            freePosition[P1] = false;

                        }

                    }
                }
            }

            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("      ");
                Console.WriteLine("({0} , {1}) ", (i + size),empPosition[i]);

            }
        }
    }

}
