﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gale_Shapley_Stable_matching
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            Console.WriteLine("I'm the CEO of this Company. \n I observed fron the last month");
            Console.WriteLine("that some employees are not performing their tasks interestingly. ");
            Console.WriteLine("So I have decided to resolve this issue. I am going to use Gale_Shapley Algo to solve it....  ");
            Console.WriteLine("For this purpose I have to create a form to get some information about preference list\n of employees. We have also preference list for the particular positions of employees");
            Console.WriteLine("Here 0 to 4 are numbers of positions and 5 to 9 are numbers of employees");
            int[][] empPrefer = new int[10][];

            empPrefer[0] = new int[] { 9, 7, 8, 5, 6 };
            empPrefer[1] = new int[] { 7, 5, 6, 9, 8 };
            empPrefer[2] = new int[] { 5, 6, 7, 8, 9 };
            empPrefer[3] = new int[] { 8, 9, 7, 6, 5 };
            empPrefer[4] = new int[] { 6, 8, 5, 7, 9 };
            empPrefer[5] = new int[] { 0, 1, 3, 2, 4 };
            empPrefer[6] = new int[] { 2, 3, 4, 1, 0 };
            empPrefer[7] = new int[] { 1, 3, 2, 4, 0 };
            empPrefer[8] = new int[] { 2, 3, 1, 4, 0 };
            empPrefer[9] = new int[] { 0, 2, 1, 4, 3 };
            int x = 0;
            foreach (int []item in empPrefer)
            {
                if(x<5)
                {
                    Console.Write("Position{0} {1}",(x+1)," Preference list: ");
                }
                else if(x>=5)
                {
                    Console.Write("Employee{0} {1}", (x - 4), " Preference list: ");
                }

                foreach  (int element in item)
                {
                    Console.Write("{0}  ",element);
                }
                Console.WriteLine();
                x++;
            }

            Stable_Matching mat = new Stable_Matching();
            Console.WriteLine("\n\nStable pairs of Employee and Position:- \n (Position , Employee)");
            mat.StableMatching(empPrefer);

            Console.ReadLine();
            
        }
    }
}
